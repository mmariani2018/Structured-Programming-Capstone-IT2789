package numberToWords;

import javax.swing.JOptionPane;

public class NumbersToWords 
{ 

	public NumbersToWords() 
	{
		String temp = "";
		String result = "";
		String input;
		double tempDouble;
			
			do
			{
				
			 input = enterNumber();
			
			}while(!validateInput(input));
			
			tempDouble = Double.parseDouble(input);
			
			if(input.length() > 3)
			{
				
				for(int a = 0; a < input.length()-3; a++)
				{
					temp += input.charAt(a);
				}
				result += findingThreeNumbers(temp) + " thousand ";
				
			}
			
			result += findingThreeNumbers(input);
			
			JOptionPane.showMessageDialog(null, "your number " + input + " in word is " + result);
	}
		
		public String findingThreeNumbers(String number)
		{
			String result;
			
			result = findHundreds(number);
			
			result += FindingTens(number);
			
			if (number.length() > 1 && findCharacter(number, 2) != '1')
				result += FindingOnes(number);
			
			return result;
			
		}
		
		public String FindingOnes(String theNumber)
		{			
			char character = findCharacter(theNumber,1);
			
			return decodeOnesAndHundredsPlace(character);
				
		}
		
		public String FindingTens(String theNumber)
		{
			if(theNumber.length() > 1)
			{
				char character = findCharacter(theNumber, 2);
				
				if(character == '1')
				{
					return decodeTeens(theNumber);
				}
				else
				{
					return decodeTensPlace(theNumber, character) + " ";
				}
				
			}
			
			return "";
		}
		
		public String findHundreds(String number)
		{
			if(number.length()> 2)
			{
				char character = findCharacter(number, 3);
				
				return decodeOnesAndHundredsPlace(character) + " hundred ";	
			}
			
			return "";
		}
		
		public String decodeOnesAndHundredsPlace(char character)
		{
			String number;
			
			switch(character)
			{
			
			case '0':
				number = "";
				break;
				
			case '1':
				number = "one";
				break;
				
			case '2':
				number = "two";
				break;
				
			case '3':
				number = "three";
				break;
				
			case '4':
				number = "four";
				break;
				
			case '5':
				number = "five";
				break;
				
			case '6':
				number = "six";
				break;
				
			case '7':
				number = "seven";
				break;
				
			case '8':
				number = "eight";
				break;
				
			case '9':
				number = "nine";
				break;
				
				default:
					number = "error";
					break;			
			}
			
			return number;
		}
		
		public String decodeTensPlace(String theNumber, char character)
		{
			String number;
			
			switch(character)
			{
			
			case '0':
				number = "";
				break;
				
			case '1':
				number = decodeTeens(theNumber);
				break;
				
			case '2':
				number = "twenty";
				break;
				
			case '3':
				number = "thrirty";
				break;
				
			case '4':
				number = "fourty";
				break;
				
			case '5':
				number = "fifty";
				break;
				
			case '6':
				number = "sixty";
				break;
				
			case '7':
				number = "seventy";
				break;
				
			case '8':
				number = "eighty";
				break;
				
			case '9':
				number = "ninety";
				break;
				
				default:
					number = "error";
					break;			
			}
			
			return number;
		}
		
			
		public String decodeTeens(String theNumber)
		{
			String number;		
			char character = findCharacter(theNumber, 1);
			
			switch(character)
			{
			
			case '1':
				number = "eleven";
				break;
				
			case '2':
				number = "twelve";
				break;
				
			case '3':
				number = "thirteen";
				break;
				
			case '4':
				number = "fourteen";
				break;
				
			case '5':
				number = "fifteen";
				break;
				
			case '6':
				number = "sixteen";
				break;
				
			case '7':
				number = "seventeen";
				break;
				
			case '8':
				number = "eighteen";
				break;
				
			case '9':
				number = "nineteen";
				break;
				
			default:
				number = "error";
				break;		
			
			}
			
			return number;
		}
		
		public char findCharacter(String theNumber, int digit)
		{
			char character;
			
			int numCharacters = theNumber.length();
			
			numCharacters -= digit;
			
			character = theNumber.charAt(numCharacters);
			
			return  character;
		}
		
		public String enterNumber()
		{
			return JOptionPane.showInputDialog("enter a number");
		}
		
		
		
		public String round(double number,  int place)
		{
			number /= Math.pow(10, 3);
			
			double tempDouble = (number * Math.pow(10, place));
			
			tempDouble += .5;
			
			int tempInt = (int) tempDouble;
			
			return Integer.toString(tempInt);
		}	
		
		public boolean validateInput(String input)
		{
					
		            int maxLengthWithSign = 7;
		            int maxLengthWithoutSign = 6;
		            int maxLength;
		            

		            //don't deal with null inputs
		            if (input == null)
		                return false;

		            //make sure the input is a valid double
		            try
		            {
		                Double.parseDouble(input);
		            }
		            catch(Exception e)
		            {
		                return false;
		            }

		            //max length with or without sign
		            if (input.charAt(0) == '+' || input.charAt(0) == '-')
		                maxLength = maxLengthWithSign;
		            else
		                maxLength = maxLengthWithoutSign;

		            //if decimal point is it in a valid place
		            if(input.contains("."))
		            {
		                int decimalAt = 0;

		                for(int n = 0; n < input.length();n++)
		                {
		                    if(!(input.charAt(n) == '.'))
		                    {
		                        decimalAt++;
		                    }

		                    if (input.length() - 3 < decimalAt)
		                        return false;
		                }

		                if (decimalAt < 7)
		                    return true;
		                else
		                    return false;
		            }
		            else//if no decimal point, is it too long
		            {
		                if (input.length() > maxLength)
		                    return false;

		                return true;
		            }	
		
		
		}
}
